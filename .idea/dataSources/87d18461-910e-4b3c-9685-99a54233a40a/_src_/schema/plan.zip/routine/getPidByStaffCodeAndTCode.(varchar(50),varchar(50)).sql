CREATE FUNCTION getPidByStaffCodeAndTCode(staffcode VARCHAR(50), tcode VARCHAR(50))
  RETURNS VARCHAR(50)
  BEGIN
	#Routine body goes here...
	DECLARE x VARCHAR(50);
	SET x = @staffcode+'_'+@tcode;
	RETURN x;
END;
